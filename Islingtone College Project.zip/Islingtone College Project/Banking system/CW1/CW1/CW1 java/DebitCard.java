

import static javax.swing.JOptionPane.showMessageDialog;

public class DebitCard extends BankCard
{
    private String withDrawalDate;
    private int pinNumber;
    private int withdrawalAmount;
    private boolean hasWithdrawn;

    public DebitCard(String clientName,int balanceAmount,int cardId ,String bankAccount, String issuerBank, int pinNumber, int withdrawalAmount, String withDrawalDate)
    {
        super(clientName,balanceAmount, cardId,bankAccount, issuerBank);
        this.pinNumber= pinNumber;
        this.withDrawalDate = withDrawalDate;
        this.withdrawalAmount = withdrawalAmount;
        hasWithdrawn= false;
    }

    public void remove(){
        hasWithdrawn = false;
        pinNumber = 0;
        super.setClientName("");
        super.setBalanceAmount(0);
        super.setCardId(0);
        super.setBankAccount("");
        super.setIssuerBank("");
    }

    int getPinNumber(){
        return pinNumber;
    }

    int getBalance(){
        return super.getBalanceAmount();
    }

    public void withdraw(int cardId, int withdrawalAmount, String withDrawalDate, int pinNumber) {
        super.setCardId(cardId);
        this.pinNumber = pinNumber;
        this.withdrawalAmount = withdrawalAmount;
        this.withDrawalDate = withDrawalDate;
       super.setBalanceAmount(super.getBalanceAmount()-withdrawalAmount);
    }

}