import java.util.Objects;

import static java.lang.System.out; //import out variable from System class to avoid writing System.out multiple times in this class

public class BankCard
{
    // bank card has following five attributes
    private int cardId;
    private String clientName;
    private String issuerBank;
    private String bankAccount;
    private int balanceAmount;

    public BankCard( String clientName,int balanceAmount,int cardId ,String bankAccount, String issuerBank)
    {
        this.clientName = ""; //initialised with empty string
        this.cardId = cardId;
        this.bankAccount = bankAccount;
        this.balanceAmount = balanceAmount;
        this.issuerBank = issuerBank;
    }

    public void setClientName(String clientName){
        this.clientName = clientName;
    }

    //following method is used to display the details of the customer regsitered inside the bank system.
    public void display(){
        System.out.println("Displaying the account holder details: " );
        System.out.println("Card Id: " + cardId );
        System.out.println("Client Name: " + clientName );
        System.out.println("Total balance amount: " + balanceAmount );
        System.out.println("Bank Account number: " + bankAccount);
        System.out.println("Issued from " + issuerBank);

    }

    public int getCardId(){
        return cardId;
    }

    public int getBalanceAmount(){
        return balanceAmount;
    }

    public void setBalanceAmount(int balanceAmount){
        this.balanceAmount = balanceAmount;
    }

    protected void setCardId(int i) {
        cardId = i;
    }

    protected void setBankAccount(String s) {
        bankAccount = s;
    }

    protected void setIssuerBank(String s) {
        issuerBank = s;
    }
}