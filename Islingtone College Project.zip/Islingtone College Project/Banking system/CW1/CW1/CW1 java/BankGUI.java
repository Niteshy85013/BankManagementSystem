import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import static javax.swing.JOptionPane.*;
import static java.lang.Integer.parseInt;


class BankGUI { //since constructor is private, class is final without the keyword
    //final keyword in field creates a constant
    private final JFrame frame;

    private final JPanel academicPanel, nonAcademicPanel;

    private final EventHandler eventHandler = new EventHandler();

    //store objects
    private final List<BankCard> bankCards = new ArrayList<>();

    private JButton creditButton, debitButton;

    private final List<JTextField> textFields = new ArrayList<>();

    public static void main(String[] args) {
        bankGUI = new BankGUI(); //first create and run object, then initialize the variable
    }

    //singleton instance. prevent 2 frames from showing up at a time
    private static BankGUI bankGUI;
    public static BankGUI getInstance() {
        return bankGUI;
    }

    private BankGUI() {
        class Panel { //do not expose methods of this local class outside constructor
            void setUpDebitPanel(JPanel p) {
                addSwitcher(p);

                //labels
                setLabel(p,"Debit card", 181, 0, 800, 100, 30);
                setLabel(p,"Client name:", 20, 90, 110, 20, 15);
                setLabel(p,"Balance amount:", 400, 140, 130, 20, 15);
                setLabel(p,"Card ID:", 400, 90, 125, 20, 15);
                setLabel(p,"Bank account:", 20, 140, 125, 20, 15);
                setLabel(p,"Issuer Bank:", 36, 190, 125, 20, 15);
                setLabel(p,"Pin number:", 400, 190, 165, 20, 15);
                setLabel(p,"Withdrawal amount:", 36, 240, 165, 20, 15);
                setLabel(p,"Withdrawal date:", 400, 240, 165, 20, 15);

                //text fields
                setTextField(p,180, 85, 170);
                setTextField(p,535, 85, 160);
                setTextField(p,180, 135, 170);
                setTextField(p,535, 135, 170);
                setTextField(p,180, 185, 160);
                setTextField(p,535, 185, 160);
                setTextField(p,180, 235, 160);
                setTextField(p,535, 235, 160);

                //buttons
                setButton(p,"Add debit card", 5, 380, 250);
                setButton(p,"Display debit cards", 5, 330, 250);
                setButton(p,"Clear", 465, 330, 260);
                setButton(p,"Withdraw", 465, 380, 260);

                //border around panel
                p.setBorder(BorderFactory.createLineBorder(Color.BLUE));
                p.setSize(740,440); //width, height
                p.setVisible(false); //hide by default
            }

            void setUpCreditPanel(JPanel p) {
                addSwitcher(p);

                setButton(p,"Remove credit card", 290, 330, 130);

                //labels
                setLabel(p,"Credit card", 250, 0, 800, 100, 30);
                setLabel(p,"Client name:", 20, 90, 130, 20, 15);
                setLabel(p,"Issuer bank:", 20, 140, 130, 20, 15);
                setLabel(p,"Bank account:", 400, 240, 130, 20, 15);
                setLabel(p,"Balance amount:", 400, 290, 130, 20, 15);
                setLabel(p,"Card ID:", 400, 90, 125, 20, 15);
                setLabel(p,"Expiration date:", 370, 140, 270, 20, 15);
                setLabel(p,"CVC number:", 400, 190, 130, 20, 15);
                setLabel(p,"Credit limit:", 20, 290, 125, 20, 15);
                setLabel(p,"Interest rate:", 20, 190, 125, 20, 15);
                setLabel(p,"Grace period:", 20, 240, 125, 20, 15);

                //text fields
                setTextField(p,180, 85, 170);
                setTextField(p,535, 85, 160);
                setTextField(p,180, 135, 170);
                setTextField(p,535, 135, 170);
                setTextField(p,180, 185, 160);
                setTextField(p,535, 185, 160);
                setTextField(p,190, 235, 160);
                setTextField(p,535, 235, 160);
                setTextField(p,180, 285, 170);
                setTextField(p,535, 285, 170);

                //buttons
                setButton(p,"Add Credit card", 5, 380, 250);
                setButton(p,"Display credit cards", 5, 330, 250);
                setButton(p,"Clear", 465, 330, 260);
                setButton(p,"Set credit limit", 465, 380, 260);

                //border around panel
                p.setBorder(BorderFactory.createLineBorder(Color.BLUE));
                p.setSize(740,440);
            }

            void addSwitcher(JPanel panel) {
                //anonymous class extending JButton with this object
                creditButton = new JButton("Credit card"){//enabled by default
                    { //default constructor without parameters (instance initializer)
                        setBackground(new Color(6,181,223));//light blue
                        setBounds(350,5,100,20);
                        //when button is clicked
                        addActionListener(eventHandler);
                        //add this components instance to panel
                        panel.add(this);
                    }
                };
                //anonymous class extending JButton with this object
                debitButton = new JButton("Debit card"){
                    { //default constructor without parameters (instance initializer)
                        setBackground(Color.GRAY);
                        setBounds(450,5,135,20);
                        //when button is clicked
                        addActionListener(eventHandler);
                        //add this components instance to panel
                        panel.add(this);
                    }
                };
                //question
                setLabel(panel, "Which type of card do you want to create?",5,0,350,30,15);
            }

            void setLabel(JPanel panel, String text, int x, int y, int width, int height, int fontSize) {
                new JLabel(text) { //creating anonymous class extending JLabel with this object
                    { //default constructor without parameters (instance initializer)
                        setBounds(x, y, width, height);
                        setFont(new Font(null, Font.PLAIN, fontSize));
                        panel.add(this); //add this JLabel instance to panel
                    }
                };
            }

            void setButton(JPanel panel, String text, int x, int y, int width) {
                new JButton(text) { //creating anonymous class extending JButton with this object
                    { //default constructor without parameters (instance initializer)
                        setBounds(x, y, width, 30); //position and size of button
                        addActionListener(eventHandler); //when button is clicked
                        panel.add(this); //add this JButton instance to panel
                    }
                };
            }

            void setTextField(JPanel panel, int x, int y, int width) {
                new JTextField() { //creating anonymous class extending JTextField with this object
                    { //default constructor without parameters
                        setBounds(x, y, width, 25);
                        textFields.add(this);
                        //on change
                        getDocument().addDocumentListener(new DocumentListener(){
                                @Override
                                public void changedUpdate(DocumentEvent e){}

                                @Override
                                public void removeUpdate(DocumentEvent e){}

                                @Override
                                public void insertUpdate(DocumentEvent e){
                                    eventHandler.removeCard = null; //reset
                                }
                            });
                        panel.add(this); //add this JTextField instance to panel
                    }
                };
            }
        }

        academicPanel = new JPanel(null); //with null layout manager for absolute position
        nonAcademicPanel = new JPanel(null);

        new Panel(){
            {//default constructor without parameters (instance initializer)
                setUpCreditPanel(academicPanel);
                setUpDebitPanel(nonAcademicPanel);
            }
        };

        frame = new JFrame("Course Registration"){
            {
                setSize(748,472);
                add(academicPanel);
                add(nonAcademicPanel); //hide by default
                setLocationRelativeTo(null);
                addWindowListener(eventHandler); //when user presses X button to close program
                setVisible(true);
            }
        };
    }

    public JFrame getFrame() {
        return frame;
    }

    void showTempDialogBox(String message){
        JOptionPane pane = new JOptionPane();
        //Do not use showMessageDialog() since we need more control for this scenario
        JDialog dialog = pane.createDialog(frame, message);

        /*
         * Dialog box position logic
         * For X axis: 
         * X = get curent X coordinate of frame
         * W = get current width of frame
         * X = X+(W/2)-(width of dialog box / 2)
         * For Y axis: 
         * Y = get curent Y coordinate of frame
         * H = get current width of frame
         * Y = Y + H- height of dialog box
         * This algorithm should make dialog box position dynamic
         */

        final int w = 150; //width
        final int h = 30; //height
        dialog.setBounds(frame.getX()+(frame.getWidth()/2)-(w/2),
            frame.getY()+frame.getHeight()-h, w, h);

        //make dialog behaviour non blocking, asynchronous 
        dialog.setModalityType(Dialog.ModalityType.MODELESS);
        dialog.setVisible(true); //show/enable
        try{
            Thread.sleep(500); //sleep thread (block everything if not parallel) for half a second
        }finally{//we don't need catch block if finally block returns from method
            dialog.setVisible(false); //hide/disable
            return;
        }
    }

    //WindowAdapter is an abstract class, ActionListener is an interface
    private class EventHandler extends WindowAdapter implements ActionListener{

        private String getText(int index) {
            return textFields.get(index).getText();
        }

        @Override //when user presses X button to close program
        public void windowClosing(WindowEvent e) {
            showMessageDialog(frame, "Thank you for trying");
            System.exit(0); //terminate program with safe signal
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            switch(e.getActionCommand()) { //enhanced switch
                case "Clear"->{
                        //clear text of all textFields
                        for(JTextField t : textFields)t.setText("");
                    }
                case "Add Credit card"-> addCreditCard();
                case "Add debit card"-> addDebitCard();
                case "Display credit cards" -> {
                        for(BankCard c : bankCards)
                            if(c instanceof CreditCard creditCard) {
                                creditCard.display();
                            }
                    }
                case "Display debit cards"->{
                        for(BankCard c : bankCards)
                        //check if c is NonAcademicCourse
                            if(c instanceof DebitCard debitCard) {
                                debitCard.display();
                            }
                    }
                case "Remove debit card"-> removeDebitCard();
                case "Remove credit card"-> removeCreditCard();
                case "Set credit limit"-> setCreditLimit();
                case "Withdraw"-> withdraw();
                case "Credit card"->{
                        academicPanel.setVisible(true);
                        nonAcademicPanel.setVisible(false);
                    }
                case "Debit card"->{
                        debitButton.setBackground(Color.RED);
                        creditButton.setBackground(Color.GRAY);
                        academicPanel.setVisible(false);
                        nonAcademicPanel.setVisible(true);
                    }
            }
        }

        private void showParseError(Exception e) {
            String log = e.getMessage();
            if(e instanceof NumberFormatException)
                log = "Please input valid integer\n" + log; //prepend
            showMessageDialog(frame, log, "Error", ERROR_MESSAGE);
        }  
        //to not reset on every click
        private DebitCard removeCard;
        private CreditCard removeCardCredit;

        private void removeDebitCard() {
            //reset at every press

            final int cardId = Integer.parseInt(getText(11));
            for(BankCard c : bankCards)
                if(c instanceof DebitCard card && c.getCardId() == cardId) {
                    removeCard = card;
                    bankCards.remove(c);
                    break; //break loop and avoid concurrent modification exception
                }
            //was true in some point. So we dont need to check text
            if(removeCard !=null) removeCard.remove(); //remove if exists
            else showTempDialogBox("Not added yet");
        }

        private void removeCreditCard() {
            try{
                final int cardId = Integer.parseInt(getText(1));
                for(BankCard c : bankCards)
                    if(c instanceof CreditCard card && c.getCardId() == cardId) {
                        removeCardCredit = card;
                        bankCards.remove(c);
                        showTempDialogBox("removed");
                        break; //break loop and avoid concurrent modification exception
                    }
                    else showTempDialogBox("Not added yet");
            }catch (Exception e){
                showMessageDialog(frame, e.getMessage(), "error", 0);
            }
        }

        private void addCreditCard() {
            try{
                var clientName = getText(0);
                var cardId = Integer.parseInt(getText(1));
                var issuerBank = getText(2);
                var expirationDate = getText(3);
                var interestRate = Integer.parseInt(getText(4));
                var cvcNumber = Integer.parseInt(getText(5));
                var gracePeriod = Integer.parseInt(getText(6));
                var bankAccount = getText(7);
                var creditLimit = Integer.parseInt(getText(8));
                var balanceAmount = Integer.parseInt(getText(9));
                BankCard bankCard = new CreditCard(clientName, balanceAmount, cardId, bankAccount, issuerBank, cvcNumber, interestRate, expirationDate, creditLimit, gracePeriod);
                //if any exception occurs, it will never reach bellow block
                addCard(bankCard);
            }catch(Exception e){ //all exceptions
                showParseError(e); //NumberFormatException is separately handled inside this method
            }
        }

        private void addDebitCard() {
            try{
                final int pinNumber = Integer.parseInt(getText(15));
                final String clientName = getText(10);
                final String bankAccount = getText(12);
                final int balanceAmount = parseInt(getText(13));
                final int cardId = parseInt(getText(11));
                final String issuerBank = getText(14);
                var withdrawalAmount = Integer.parseInt(getText(16));
                var withdrawalDate = getText(17);
                BankCard bankCard = new DebitCard(clientName, balanceAmount, cardId, bankAccount, issuerBank, pinNumber, withdrawalAmount, withdrawalDate);
                //if any exception occurs, it will never reach bellow block
                addCard(bankCard);
            }catch(Exception e){ //all exceptions
                showParseError(e); //NumberFormatException is separately handled inside this method
            }
        }

        private void addCard(BankCard bankCard) {
            String cardId = (bankCard instanceof CreditCard) ? getText(1) : getText(11);

            for(BankCard c : bankCards)
                if(c.getCardId() == Integer.parseInt(cardId)) {
                    showMessageDialog(
                        //'this' can not be used directly as this block is in an internal class
                        BankGUI.this.getFrame(),"The card has already been added.",
                        "Warning",WARNING_MESSAGE
                    );
                    return; //terminate this method, do not add to arraylist or loop
                }
            bankCards.add(bankCard); //if condition inside loop above is never true
            showTempDialogBox("Adding..");
        }

        private void setCreditLimit() {
            try{
                final int cardId = Integer.parseInt(getText(1));
                var creditLimit = Integer.parseInt(getText(8));
                var gracePeriod = Integer.parseInt(getText(6));
                for(BankCard c : bankCards)
                    if(c instanceof CreditCard creditCard && cardId == c.getCardId()) {
                        creditCard.setCreditLimit(
                                cardId, creditLimit, gracePeriod
                        );

                        showMessageDialog(
                                //'this' can not be used directly as this block is in an internal class
                                BankGUI.this.getFrame(),"Credit card limit has been set",
                                "Success", INFORMATION_MESSAGE
                        );
                    }
            }catch (Exception e)
            {
                showMessageDialog(frame, e.getMessage(), "error", ERROR_MESSAGE);
            }
        }

        private void withdraw() {
            try{
                final int cardId = Integer.parseInt(getText(11));
                final int pinNumber = Integer.parseInt(getText(15));
                final int withDrawalAmount = Integer.parseInt(getText(16));
                final String withdrawalDate = getText(17);
                if(bankCards.size()==0) showMessageDialog(frame, "No card found", "error", 0);
                for(BankCard c : bankCards)
                    if(c instanceof DebitCard debitCard && cardId == c.getCardId()) {
                        if(debitCard.getPinNumber()!=pinNumber){
                            showMessageDialog(frame, "Invalid pin", "error", 0);
                        }else if(debitCard.getBalance() < withDrawalAmount){
                            showMessageDialog(frame, "Card limit reached", "error", 0);
                        }else{
                            showMessageDialog(frame, "withdrawn");
                            debitCard.withdraw(
                                    cardId, withDrawalAmount, withdrawalDate, pinNumber
                            );
                        }
                    }
            }catch (Exception e){
                showMessageDialog(frame, e.getMessage(), "error", 0);
            }
        }
    }
}