import static javax.swing.JOptionPane.WARNING_MESSAGE;
import static javax.swing.JOptionPane.showMessageDialog;

public class CreditCard extends BankCard
{
    private int cvcNumber;
    private double creditLimit;
    private double interestRate;
    private String expirationDate;
    private int gracePeriod;
    private boolean isGranted;
    //constructor is being created
    public CreditCard(String clientName, int balanceAmount, int cardId,String bankAccount, String issuerBank, int cvcNumber, double interestRate, String expirationDate, int creditLimit, int gracePeriod){
        super(clientName,balanceAmount, cardId,bankAccount, issuerBank);
        this.cvcNumber = cvcNumber;
        this.interestRate = interestRate;
        this.expirationDate = expirationDate;
        this.creditLimit=  0;
        this.gracePeriod=  0;
        isGranted = false;
    }

    public void setCreditLimit(int cardId, int creditLimit, int gracePeriod){
        super.setCardId(cardId);
        this.creditLimit = creditLimit;
        this.gracePeriod = gracePeriod;
    }

    public void remove(){
        this.gracePeriod = 0;
        this.creditLimit = 0;
        this.cvcNumber = 0;
        this.isGranted = false;
        this.interestRate = 0d;
        super.setClientName("");
        super.setBalanceAmount(0);
        super.setCardId(0);
        super.setBankAccount("");
        super.setIssuerBank("");
    }

    public void display(){
        //incase of customer takes credit following display method shows the following output.
        if(isGranted){
            System.out.println("Display the credit card details");
            super.display();
            System.out.println("Grace Period: " + gracePeriod);
            System.out.println("Credit Limit: " + creditLimit);
        }
        //incase of no credit taken of the details of the customer are displayed.
        if(!isGranted){
            super.display();
        }
    }
}